
function nuevaVentana(){
	window.open("http://www.issabel.org/documentation/issabel_administrator_manual.pdf", "Issabel", "height=600,width=600");
}

